
      let global = globalThis;

      if (typeof global.navigator === 'undefined') {
        global.navigator = {
          userAgent: 'edge-runtime',
          language: 'en-US',
          languages: ['en-US'],
        };
      } else {
        if (typeof global.navigator.language === 'undefined') {
          global.navigator.language = 'en-US';
        }
        if (!global.navigator.languages || global.navigator.languages.length === 0) {
          global.navigator.languages = [global.navigator.language];
        }
        if (typeof global.navigator.userAgent === 'undefined') {
          global.navigator.userAgent = 'edge-runtime';
        }
      }

      class MessageChannel {
        constructor() {
          this.port1 = new MessagePort();
          this.port2 = new MessagePort();
        }
      }
      class MessagePort {
        constructor() {
          this.onmessage = null;
        }
        postMessage(data) {
          if (this.onmessage) {
            setTimeout(() => this.onmessage({ data }), 0);
          }
        }
      }
      global.MessageChannel = MessageChannel;

      // if ((typeof globalThis.fetch === 'undefined' || typeof globalThis.Headers === 'undefined' || typeof globalThis.Request === 'undefined' || typeof globalThis.Response === 'undefined') && typeof require !== 'undefined') {
      //   try {
      //     const undici = require('undici');
      //     if (undici.fetch && !globalThis.fetch) {
      //       globalThis.fetch = undici.fetch;
      //     }
      //     if (undici.Headers && typeof globalThis.Headers === 'undefined') {
      //       globalThis.Headers = undici.Headers;
      //     }
      //     if (undici.Request && typeof globalThis.Request === 'undefined') {
      //       globalThis.Request = undici.Request;
      //     }
      //     if (undici.Response && typeof globalThis.Response === 'undefined') {
      //       globalThis.Response = undici.Response;
      //     }
      //   } catch (polyfillError) {
      //     console.warn('Edge middleware polyfill failed:', polyfillError && polyfillError.message ? polyfillError.message : polyfillError);
      //   }
      // }

      function recreateRequest(request, overrides = {}) {
        const cloned = typeof request.clone === 'function' ? request.clone() : request;
        const headers = new Headers(cloned.headers);

        if (overrides.headerPatches) {
          Object.keys(overrides.headerPatches).forEach((key) => {
            const value = overrides.headerPatches[key];
            if (value === null || typeof value === 'undefined') {
              headers.delete(key);
            } else {
              headers.set(key, value);
            }
          });
        }

        if (overrides.headers) {
          const extraHeaders = new Headers(overrides.headers);
          extraHeaders.forEach((value, key) => headers.set(key, value));
        }

        const url = overrides.url || cloned.url;
        const method = overrides.method || cloned.method || 'GET';
        const canHaveBody = method && method.toUpperCase() !== 'GET' && method.toUpperCase() !== 'HEAD';
        const body = overrides.body !== undefined ? overrides.body : canHaveBody ? cloned.body : undefined;

        // 如果rewrite传入的是完整URL（第三方地址），需要更新host
        if (overrides.url) {
          try {
            const newUrl = new URL(overrides.url, cloned.url);
            // 只有当新URL是绝对路径（包含协议和host）时才更新host
            if (overrides.url.startsWith('http://') || overrides.url.startsWith('https://')) {
              headers.set('host', newUrl.host);
            }
            // 相对路径时保持原有host不变
          } catch (e) {
            // URL解析失败时保持原有host
          }
        }

        const init = {
          method,
          headers,
          redirect: cloned.redirect,
          credentials: cloned.credentials,
          cache: cloned.cache,
          mode: cloned.mode,
          referrer: cloned.referrer,
          referrerPolicy: cloned.referrerPolicy,
          integrity: cloned.integrity,
          keepalive: cloned.keepalive,
          signal: cloned.signal,
        };

        if (canHaveBody && body !== undefined) {
          init.body = body;
        }

        if ('duplex' in cloned) {
          init.duplex = cloned.duplex;
        }

        return new Request(url, init);
      }

      
      async function executeMiddleware(context) {
        return null; // 没有中间件，继续执行后续函数
      }
    

      async function handleRequest(context){
        let routeParams = {};
        let pagesFunctionResponse = null;
        let request = context.request;
        const waitUntil = context.waitUntil;
        let urlInfo = new URL(request.url);

        const normalizePathname = () => {
          if (urlInfo.pathname !== '/' && urlInfo.pathname.endsWith('/')) {
            urlInfo.pathname = urlInfo.pathname.slice(0, -1);
          }
        };

        normalizePathname();

        let matchedFunc = false;

        
        const runEdgeFunctions = () => {
        
          if(!matchedFunc && '/hello-edge' === urlInfo.pathname) {
            matchedFunc = true;
              "use strict";
(() => {
  // edge-functions/hello-edge.js
  function onRequest(context) {
    const { geo } = context;
    return new Response(JSON.stringify({
      message: "Hello Edge!",
      geo
    }), {
      headers: {
        "Content-Type": "application/json"
      }
    });
  }

        pagesFunctionResponse = onRequest;
      })();
          }
        
        };
        

        
        const middlewareRequest = request && typeof request.clone === 'function' ? request.clone() : request;
        const middlewareResponse = await executeMiddleware({
          request: middlewareRequest,
          urlInfo: new URL(urlInfo.toString()),
          env: {"NODE":"/usr/local/bin/node","INIT_CWD":"/Users/clavie/Desktop/framework/next-mix-render-template-main","SHELL":"/bin/sh","TERM":"xterm-256color","npm_config_global_prefix":"/usr/local","COLOR":"1","npm_config_noproxy":"","npm_config_registry":"http://tnpm.woa.com/","npm_config_local_prefix":"/Users/clavie/Desktop/framework/next-mix-render-template-main","USER":"root","SUDO_USER":"clavie","npm_config_globalconfig":"/usr/local/etc/npmrc","SUDO_UID":"501","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.7zkG0vd9vI/Listeners","__CF_USER_TEXT_ENCODING":"0x0:25:52","npm_execpath":"/usr/local/lib/node_modules/npm/bin/npm-cli.js","MAIL":"/var/mail/root","PATH":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache/_npx/58a1ee554720702d/node_modules/.bin:/Users/clavie/Desktop/framework/next-mix-render-template-main/node_modules/.bin:/Users/clavie/Desktop/framework/node_modules/.bin:/Users/clavie/Desktop/node_modules/.bin:/Users/clavie/node_modules/.bin:/Users/node_modules/.bin:/node_modules/.bin:/usr/local/lib/node_modules/npm/node_modules/@npmcli/run-script/lib/node-gyp-bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Users/clavie/.local/bin","npm_package_json":"/Users/clavie/Desktop/framework/next-mix-render-template-main/package.json","npm_config_userconfig":"/Users/clavie/.npmrc","npm_config_init_module":"/Users/clavie/.npm-init.js","PWD":"/Users/clavie/Desktop/framework/next-mix-render-template-main","npm_command":"exec","npm_lifecycle_event":"npx","EDITOR":"vi","npm_package_name":"next-mix-template","LANG":"zh_CN.UTF-8","npm_config_npm_version":"10.9.2","npm_config_node_gyp":"/usr/local/lib/node_modules/npm/node_modules/node-gyp/bin/node-gyp.js","npm_package_version":"0.1.0","SHLVL":"1","SUDO_COMMAND":"/usr/local/bin/npx --registry=http://tnpm.woa.com/ @tencent/edgeone@1.2.15-beta.16 pages build","HOME":"/Users/clavie","npm_config_cache":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache","LOGNAME":"root","npm_lifecycle_script":"edgeone","npm_config_user_agent":"npm/10.9.2 node/v22.14.0 darwin arm64 workspaces/false","SUDO_GID":"20","npm_node_execpath":"/usr/local/bin/node","npm_config_prefix":"/usr/local","COLORTERM":"truecolor","_":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache/_npx/58a1ee554720702d/node_modules/.bin/edgeone","NEXT_PRIVATE_STANDALONE":"true"},
          waitUntil
        });

        if (middlewareResponse) {
          const headers = middlewareResponse.headers;
          const hasNext = headers && headers.get('x-middleware-next') === '1';
          const rewriteTarget = headers && headers.get('x-middleware-rewrite');
          const requestHeadersOverride = headers && headers.get('x-middleware-request-headers');

          if (rewriteTarget) {
            try {
              const rewrittenUrl = rewriteTarget.startsWith('http://') || rewriteTarget.startsWith('https://')
                ? rewriteTarget
                : new URL(rewriteTarget, urlInfo.origin).toString();
              request = recreateRequest(request, { url: rewrittenUrl });
              urlInfo = new URL(rewrittenUrl);
              normalizePathname();
            } catch (rewriteError) {
              console.error('Middleware rewrite error:', rewriteError);
            }
          }

          if (requestHeadersOverride) {
            try {
              const decoded = decodeURIComponent(requestHeadersOverride);
              const headerPatch = JSON.parse(decoded);
              request = recreateRequest(request, { headerPatches: headerPatch });
            } catch (requestPatchError) {
              console.error('Middleware request header override error:', requestPatchError);
            }
          }

          if (!hasNext && !rewriteTarget) {
            return middlewareResponse;
          }
        }
        
        
        // 走到这里说明：
        // 1. 没有中间件响应（middlewareResponse 为 null/undefined）
        // 2. 或者中间件返回了 next
        // 需要判断是否命中边缘函数

        runEdgeFunctions();

        if (!matchedFunc) {
          // 没有命中边缘函数，执行回源
          return await fetch(request);
        }
        
        // 命中了边缘函数，继续执行边缘函数逻辑

        const params = {};
        if (routeParams.id) {
          if (routeParams.mode === 1) {
            const value = urlInfo.pathname.match(routeParams.left);        
            for (let i = 1; i < value.length; i++) {
              params[routeParams.id[i - 1]] = value[i];
            }
          } else {
            const value = urlInfo.pathname.replace(routeParams.left, '');
            const splitedValue = value.split('/');
            if (splitedValue.length === 1) {
              params[routeParams.id] = splitedValue[0];
            } else {
              params[routeParams.id] = splitedValue;
            }
          }
          
        }
        return pagesFunctionResponse({request, params, env: {"NODE":"/usr/local/bin/node","INIT_CWD":"/Users/clavie/Desktop/framework/next-mix-render-template-main","SHELL":"/bin/sh","TERM":"xterm-256color","npm_config_global_prefix":"/usr/local","COLOR":"1","npm_config_noproxy":"","npm_config_registry":"http://tnpm.woa.com/","npm_config_local_prefix":"/Users/clavie/Desktop/framework/next-mix-render-template-main","USER":"root","SUDO_USER":"clavie","npm_config_globalconfig":"/usr/local/etc/npmrc","SUDO_UID":"501","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.7zkG0vd9vI/Listeners","__CF_USER_TEXT_ENCODING":"0x0:25:52","npm_execpath":"/usr/local/lib/node_modules/npm/bin/npm-cli.js","MAIL":"/var/mail/root","PATH":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache/_npx/58a1ee554720702d/node_modules/.bin:/Users/clavie/Desktop/framework/next-mix-render-template-main/node_modules/.bin:/Users/clavie/Desktop/framework/node_modules/.bin:/Users/clavie/Desktop/node_modules/.bin:/Users/clavie/node_modules/.bin:/Users/node_modules/.bin:/node_modules/.bin:/usr/local/lib/node_modules/npm/node_modules/@npmcli/run-script/lib/node-gyp-bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Users/clavie/.local/bin","npm_package_json":"/Users/clavie/Desktop/framework/next-mix-render-template-main/package.json","npm_config_userconfig":"/Users/clavie/.npmrc","npm_config_init_module":"/Users/clavie/.npm-init.js","PWD":"/Users/clavie/Desktop/framework/next-mix-render-template-main","npm_command":"exec","npm_lifecycle_event":"npx","EDITOR":"vi","npm_package_name":"next-mix-template","LANG":"zh_CN.UTF-8","npm_config_npm_version":"10.9.2","npm_config_node_gyp":"/usr/local/lib/node_modules/npm/node_modules/node-gyp/bin/node-gyp.js","npm_package_version":"0.1.0","SHLVL":"1","SUDO_COMMAND":"/usr/local/bin/npx --registry=http://tnpm.woa.com/ @tencent/edgeone@1.2.15-beta.16 pages build","HOME":"/Users/clavie","npm_config_cache":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache","LOGNAME":"root","npm_lifecycle_script":"edgeone","npm_config_user_agent":"npm/10.9.2 node/v22.14.0 darwin arm64 workspaces/false","SUDO_GID":"20","npm_node_execpath":"/usr/local/bin/node","npm_config_prefix":"/usr/local","COLORTERM":"truecolor","_":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache/_npx/58a1ee554720702d/node_modules/.bin/edgeone","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil });
      }
      addEventListener('fetch', event=>{return event.respondWith(handleRequest({request:event.request,params: {}, env: {"NODE":"/usr/local/bin/node","INIT_CWD":"/Users/clavie/Desktop/framework/next-mix-render-template-main","SHELL":"/bin/sh","TERM":"xterm-256color","npm_config_global_prefix":"/usr/local","COLOR":"1","npm_config_noproxy":"","npm_config_registry":"http://tnpm.woa.com/","npm_config_local_prefix":"/Users/clavie/Desktop/framework/next-mix-render-template-main","USER":"root","SUDO_USER":"clavie","npm_config_globalconfig":"/usr/local/etc/npmrc","SUDO_UID":"501","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.7zkG0vd9vI/Listeners","__CF_USER_TEXT_ENCODING":"0x0:25:52","npm_execpath":"/usr/local/lib/node_modules/npm/bin/npm-cli.js","MAIL":"/var/mail/root","PATH":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache/_npx/58a1ee554720702d/node_modules/.bin:/Users/clavie/Desktop/framework/next-mix-render-template-main/node_modules/.bin:/Users/clavie/Desktop/framework/node_modules/.bin:/Users/clavie/Desktop/node_modules/.bin:/Users/clavie/node_modules/.bin:/Users/node_modules/.bin:/node_modules/.bin:/usr/local/lib/node_modules/npm/node_modules/@npmcli/run-script/lib/node-gyp-bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Users/clavie/.local/bin","npm_package_json":"/Users/clavie/Desktop/framework/next-mix-render-template-main/package.json","npm_config_userconfig":"/Users/clavie/.npmrc","npm_config_init_module":"/Users/clavie/.npm-init.js","PWD":"/Users/clavie/Desktop/framework/next-mix-render-template-main","npm_command":"exec","npm_lifecycle_event":"npx","EDITOR":"vi","npm_package_name":"next-mix-template","LANG":"zh_CN.UTF-8","npm_config_npm_version":"10.9.2","npm_config_node_gyp":"/usr/local/lib/node_modules/npm/node_modules/node-gyp/bin/node-gyp.js","npm_package_version":"0.1.0","SHLVL":"1","SUDO_COMMAND":"/usr/local/bin/npx --registry=http://tnpm.woa.com/ @tencent/edgeone@1.2.15-beta.16 pages build","HOME":"/Users/clavie","npm_config_cache":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache","LOGNAME":"root","npm_lifecycle_script":"edgeone","npm_config_user_agent":"npm/10.9.2 node/v22.14.0 darwin arm64 workspaces/false","SUDO_GID":"20","npm_node_execpath":"/usr/local/bin/node","npm_config_prefix":"/usr/local","COLORTERM":"truecolor","_":"/Users/clavie/Desktop/framework/svelte-spa/.npm-cache/_npx/58a1ee554720702d/node_modules/.bin/edgeone","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil: event.waitUntil }))});