:HL["/_next/static/chunks/cf9f91363ea6c4d8.css","style"]
0:{"buildId":"R2G3kKMmWFj4mQzPl-OAk","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
