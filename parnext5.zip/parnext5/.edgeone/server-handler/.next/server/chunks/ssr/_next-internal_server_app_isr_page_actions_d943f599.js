module.exports=[50951,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_isr_page_actions_d943f599.js.map