module.exports=[25942,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ssg_page_actions_7c0b1172.js.map