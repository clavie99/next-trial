module.exports=[48973,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ssr_page_actions_3b95beb4.js.map