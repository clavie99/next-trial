module.exports=[95020,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_edge-functions_page_actions_15e86955.js.map